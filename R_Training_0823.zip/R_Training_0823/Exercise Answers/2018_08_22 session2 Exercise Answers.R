

#------------------------------------------------------
#      R Session 2 Exercise Answers 
#------------------------------------------------------


# ------- Exercise Question(s) -------------
# Please write and execute your code under the question:

# 1. Create a new dataset called test1 from "df" and
# create a new variable called "newvar", which will change the PSNU value "The Iron Islands" to "Charmin Islands"
# 1a. Using count, view the PSNU & newvar columns in dataset test1 

test1 <- mutate(df, newvar = 
                  if_else(PSNU == "The Iron Islands", "Charmin Islands", PSNU))
View(count(test1, PSNU, newvar))



# 2. Please create a new dataset, "test2" from "df" where you pipe these steps together:
# filter for TX_NEW
# select OperatingUnit, PSNU, indicator, FY2018Q2
# arrange PSNU
# then View it
test2 <- df %>%
  filter(indicator == "TX_NEW") %>% 
  select (OperatingUnit, PSNU, indicator, FY2018Q2) %>%
  arrange(PSNU)
View(test2)



# 3. create a new dataset, called test3 from df where you:
# filter for TX_CURR and Total Numerator 
# summarise FY2017APR 
# and group_by PSNU
# then View it to verify

test3 <- df %>%
  filter(indicator == "TX_CURR", standardizedDisaggregate == "Total Numerator") %>%
  group_by(PSNU) %>%
  summarise(FY2017APR = sum(FY2017APR, na.rm = TRUE )) %>% 
  ungroup()
View(test3)


# 4. Please create a new dataset called test4 from df and rename SNU1 to "EssEnYouOne"
# then view it to verify the name change

test4 <- rename(df, EssEnYouOne = PSNU)
View(test4)


# 5. Please create a new dataset, called test5 from df and delete RegionUID & OperatingUnitUID
# then view it to verify the columns were deleted

test5 <- select(df, -RegionUID, -OperatingUnitUID)
View (test5)

