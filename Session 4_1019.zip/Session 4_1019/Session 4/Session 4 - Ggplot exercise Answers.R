# SESSION 4 - GGPLOT
# ------- Exercise Question(s) -------------
# Please write and execute your code under the question:

# 1. Using the mpg dataset, please create a line graph with the variables, 
# cty and displ. cty is y-axis, displ is x-axis 
# 1a. Using same variables, add a scatter plot too 

ggplot (data = mpg, mappings = aes(displ, cty)) + 
  geom_line()

ggplot (data = mpg, mappings = aes(displ, cty)) + 
  geom_line() + 
  geom_point()



# ------- Exercise Question(s) -------------
# Please write and execute your code under the question:

# 2. Using the mpg dataset, please create a scatter plot with the variables, 
# cty and displ. cty is y-axis, displ is x-axis 
# 2a. Using same variables, add a color option where color equals drv
# 2b. Then, add a size option where size equals hwy
# 2c. Instead of size being equal to hwy, make it 5 and think about where it goes in the code
# 2d. change the transparency level to .2
# 2e. add labels: title: Engine size and City MPG, x-axis: Engine Size, y-axis: city MPG


ggplot(data = mpg, mapping = aes(displ, cty)) + 
  geom_point()

ggplot(data = mpg, mapping = aes(displ, cty, color = drv)) + 
  geom_point()

ggplot(data = mpg, mapping = aes(displ, cty, color = drv, size = hwy)) + 
  geom_point()

ggplot(data = mpg, mapping = aes(displ, cty, color = drv)) + 
  geom_point(size = 5)

ggplot(data = mpg, mapping = aes(displ, cty, color = drv)) + 
  geom_point(size = 5, alpha = .2)

ggplot(data = mpg, mapping = aes(displ, cty, color = drv)) + 
  geom_point(size = 5, alpha = .2) +
  scale_x_continuous(name = "Engine Size") +
  scale_y_continuous(name = "City MPG") + 
  ggtitle("Engine Size and City MPG")



# ------- Exercise Question(s) -------------
# Please write and execute your code under the question:

# 3. Import the ex2_data.txt dataset and name it test. Feel free to copy and paste the code 
# from the lesson script 
# Find out how many patients are newly receiving treatment over the past three quarters 
# 3a. Create an intermediate dataset that has data for TX_NEW total numerator and 
# aggregate totals from 17Q2-18Q2 just like the way it was done in the lesson example 
# 3b. create a line graph with period on x-axis and aggregate values on Y -axis, use group =1 statement
# 3c. add axis labels and title. use scale_x_discrete for x-axis label
# 3d. Choose a theme and/or other options if you wish 

test <- read_tsv(file = "RawData/ex2_data.txt", 
                col_types = cols(MechanismID        = "c",
                                 AgeAsEntered       = "c",            
                                 AgeFine            = "c",     
                                 AgeSemiFine        = "c",    
                                 AgeCoarse          = "c",      
                                 Sex                = "c",     
                                 resultStatus       = "c",     
                                 otherDisaggregate  = "c",     
                                 coarseDisaggregate = "c",     
                                 FY2017_TARGETS     = "d",
                                 FY2017Q1           = "d",      
                                 FY2017Q2           = "d",      
                                 FY2017Q3           = "d",      
                                 FY2017Q4           = "d",      
                                 FY2017APR          = "d",
                                 FY2018Q1           = "d",
                                 FY2018Q2           = "d",
                                 FY2018_TARGETS     = "d",
                                 FY2019_TARGETS     = "d"))

tx <- test %>%
  filter(indicator == "TX_NEW" & standardizedDisaggregate == "Total Numerator") %>%
  select(FY2017Q2, FY2017Q3, FY2017Q4, FY2018Q1, FY2018Q2) %>%
  gather(period) %>%
  group_by(period) %>%
  summarise(txvalue = sum(value, na.rm = TRUE)) %>%
  ungroup()

ggplot(data = tx, mapping = aes(period, txvalue, group = 1)) +
  geom_line () +
  scale_x_discrete(name = "Time Period") + 
  scale_y_continuous(name= "Patients new on TX") +
  ggtitle("New Patients on TX over time") +
  theme_classic()



# ------- Exercise Question(s) -------------
# Please write and execute your code under the question:

# 4.  Use the test dataset to start with
# 4a. Transform the data. Keep only TX_NEW, Total Numerator in the dataset
# 4b. Create a bar chart for OperatingUnit
# 4c. We don't want count, so add FY2018Q2 as the y value, 
#     and figure out how to display frequency in the graph
# 4d. Display a stacked bar graph instead, with FundingAgency as the 'fill' option
# 4e. Add a title of your choice 
# 4f. Add a theme of your choosing, make it elegant 



test2 <- filter(test, indicator == "TX_NEW", standardizeddisaggregate == "Total Numerator")

ggplot(data = test2, mapping = aes(OperatingUnit)) + 
  geom_bar()

ggplot(data = test2, mapping = aes(OperatingUnit, FY2018Q2)) + 
  geom_bar(stat="identity")

ggplot(data = test2, mapping = aes(OperatingUnit, FY2018Q2, fill = FundingAgency)) + 
  geom_bar(stat="identity")

ggplot(data = test2, mapping = aes(OperatingUnit, FY2018Q2, fill = FundingAgency)) + 
  geom_bar(stat="identity") + 
  labs(title = "Agency/OU Breakdown of New Patients on TX")



# ------- Exercise Question(s) -------------
# Please write and execute your code under the question:

# 5. Using the mpg dataset, create a scatterplot with displ on the x axis and hwy on the y axis
# 5a. add a facet_wrap and facet on model. 
# 5b. that was a joke...too many graphs. Facet on manufacturer instead.
# Are some creating more efficient vehicles than others?
# 5c. add axis labels, displ is engine size, hwy is highway MPG
# 5d. add a theme of your choice
# 5e. make the number of columns 3 by using ncol in the facet_wrap argument
# 5f. add the color option to the mapping argument, color should be year. See anything interesting?
# don't be afraid to expand the plot menu to view the plot better!

ggplot(data = mpg, mapping = aes(displ, hwy, color = year)) + 
  geom_point() +
  facet_wrap(~manufacturer, ncol = 3) +
  theme_minimal()+
  scale_x_continuous(name = "Engine Size") +
  scale_y_continuous(name = "Highway MPG")



