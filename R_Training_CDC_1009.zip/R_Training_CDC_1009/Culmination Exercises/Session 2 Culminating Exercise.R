
#------- Session 2 Culminating Exercise ----------
#-------------------------------------------------

# This exercise is intended for you to do indepdently after the Session 2 lesson.
# This exercise will integrate most of the methods gained from Session 2 into a 
#   simulation of analyses you may do in real life using MER data 


# Question 1: You just joined the PEPFAR Botswana field team for a second stint. 
# Use the ex2_data dataset as your starting point. 
# you need to change the names of some of the PSNUs and Partners to account for influx of migrants and other changes:
# For PSNU: North East District is now "NE District"
# For Partner: TBD is now "The Coolest" and "Dedup" is now "Confusing Inc."
# You also need to filter for KP_PREV, PP_PREV an VMMC_CIRC data only
# Also rename variables "indicator" to "Indicator" and "PrimePartner" to "ThePartner"
# please use piping in your code as it will be shared with junior staff members. 
# Export the data as Bots3.csv





# Question 2: Now that you have prepared this dataset, the Branch Chief wants to know how big the dataset is, namely, # of rows and variables. 
# Then she wants to know how many people were circumcised (VMMC_CIRC) by each Partner in FY2018Q1, as a dataset
# She also wants to know how many people were circumcised by each Partner in FY2018Q2, as another dataset
# then she wants a dataset that stacks/combines these numbers together 
# she only wants OperatingUnit, PSNU, Indicator, ThePartner, FY2018Q2 in these datasets
# please export stacked dataset as Bots4.csv
# be efficient with the coding as junior staff will use it











#---------------------------------ANSWERS-------------------------------#

# Question 1

library(tidyverse)

test <- read_tsv("RawData/ex2_data.txt",
                 col_types = cols(MechanismID        = "c",
                                  AgeAsEntered       = "c",            
                                  AgeFine            = "c",     
                                  AgeSemiFine        = "c",    
                                  AgeCoarse          = "c",      
                                  Sex                = "c",     
                                  resultStatus       = "c",     
                                  otherDisaggregate  = "c",     
                                  coarseDisaggregate = "c",     
                                  FY2017_TARGETS     = "d",
                                  FY2017Q1           = "d",      
                                  FY2017Q2           = "d",      
                                  FY2017Q3           = "d",      
                                  FY2017Q4           = "d",      
                                  FY2017APR          = "d",
                                  FY2018Q1           = "d",
                                  FY2018Q2           = "d",
                                  FY2018Q3           = "d",
                                  FY2018_TARGETS     = "d",
                                  FY2019_TARGETS     = "d"))

Bots3 <- test %>% 
  filter(indicator == "PP_PREV" | indicator == "KP_PREV" | indicator == "VMMC_CIRC") %>%
  mutate(PSNU =
         if_else(PSNU == "North East District", "NE District", PSNU)) %>%
  mutate(PrimePartner = 
         if_else(PrimePartner == "TBD", "The Coolest",
                 if_else(PrimePartner == "Dedup", "Confusing Inc.", PrimePartner))) %>%
  rename(Indicator = indicator, ThePartner = PrimePartner)
View(count(Bots3, PSNU, ThePartner, Indicator, OperatingUnit))    


write_csv(Bots3, path = "Output/Bots3.csv")



# Question 2

glimpse(Bots3)


circ1 <- Bots3 %>% 
  filter(Indicator == "VMMC_CIRC", standardizedDisaggregate == "Total Numerator") %>% 
    select(OperatingUnit, Indicator, PSNU, ThePartner, FY2018Q1)

    

circ2 <- Bots3 %>% 
  filter(Indicator == "VMMC_CIRC", standardizedDisaggregate == "Total Numerator") %>% 
    select(OperatingUnit, Indicator, PSNU, ThePartner, FY2018Q2)


Bots4 <- bind_rows(circ1, circ2)

write_csv(Bots4, path = "Output/Bots4.csv")
