
#------- Session 4 Ggplot Culminating Exercise ----------
#-------------------------------------------------

# This exercise is intended for you to do indepdently after the Session 4 Ggplot lesson.
# This exercise will integrate all of the methods gained into a 
#   simulation of analyses you may do in real life using MER data 


# Scenario: You recently joined a PEPFAR field office, and upon your arrival a new branch chief
# has also started her tenure there. 
# For some reason, she asks you (of all people) to send her information on the MER data there. 
# However, you just finished doing the R trainings at ICPI and welcome the chance to reinforce 
# what you learned! 

# Question 0: install tidyverse and import the ex2_data.txt dataset. Call the dataset ou

library(tidyverse)

ou <- read_tsv(file = "RawData/ex2_data.txt", 
                col_types = cols(MechanismID        = "c",
                                 AgeAsEntered       = "c",            
                                 AgeFine            = "c",     
                                 AgeSemiFine        = "c",    
                                 AgeCoarse          = "c",      
                                 Sex                = "c",     
                                 resultStatus       = "c",     
                                 otherDisaggregate  = "c",     
                                 coarseDisaggregate = "c",     
                                 FY2017_TARGETS     = "d",
                                 FY2017Q1           = "d",      
                                 FY2017Q2           = "d",      
                                 FY2017Q3           = "d",      
                                 FY2017Q4           = "d",      
                                 FY2017APR          = "d",
                                 FY2018Q1           = "d",
                                 FY2018Q2           = "d",
                                 FY2018_TARGETS     = "d",
                                 FY2019_TARGETS     = "d"))

# Question 1: Create bar graph showing how much data was reported by each FundingAgency in Westeros.
# create a new dataset called ou2 that has only Westeros data
# Use geom_bar

ou2 <- filter(ou, OperatingUnit == "Westeros")
ggplot(data = ou2, mapping = aes(FundingAgency)) +
  geom_bar()

# Question 2: Clean up the labels, add a title describing the graph.
# make the bars stacked with PSNU doing the stacking. 
# export the graph using ggsave. 
# Call the file culminationgraph1.pdf. Use width/height options, if needed

ggplot(data = ou2, mapping = aes(FundingAgency, fill = PSNU)) +
  geom_bar() +
  scale_y_continuous(name = "# of Rows with data") + 
  ggtitle ("Which Agency reported more data from Westeros?")

ggsave("Outputs/culminationgraph1.pdf", width = 8, height = 8)


# Question 3: Your branch chief wants to see trends over time for TX_NEW and HTS_POS
# include 17Q3 - 18Q2
# start with the ou dataset
# create one line graph with two lines, one for HTS_POS and one for TX_NEW
# give it some proper axis labels and title. Also theme it if you wish 

# create intermediate dataset for TX_NEW
txnew<-ou %>%
  filter(indicator=="TX_NEW" & standardizedDisaggregate=="Total Numerator") %>% 
  select(FY2017Q3, FY2017Q4, FY2018Q1, FY2018Q2) %>% 
  gather(period) %>% 
  group_by(period) %>% 
  summarise(value = sum(value, na.rm=T)) %>%
  ungroup() %>%
  mutate(indicator = "TX_NEW")


pos<-ou %>%
  filter(indicator=="HTS_TST_POS" & standardizedDisaggregate=="Total Numerator") %>% 
  select(FY2017Q3, FY2017Q4, FY2018Q1, FY2018Q2) %>% 
  gather(period) %>% 
  group_by(period) %>% 
  summarise(value = sum(value, na.rm=T)) %>%
  ungroup() %>%
  mutate(indicator = "HTS_POS")

# then stack the two datasets to make one

master <- bind_rows(txnew, pos)

# now plot it as a line graph. use geom_line and indicator as the group option
ggplot(data=master, mapping = aes(period, value, color = indicator, group = indicator))+
  geom_line() + 
  scale_x_discrete(name = "Time Period")+
  scale_y_continuous(name = "# of Positives or TX_NEW over Time")+
  ggtitle("Indicators Over Time") +
  theme_classic()

#Question 4: export this graph as well and call it culminatinggraph2.pdf

ggsave("Outputs/culminatinggraph2.pdf", height = 8, width = 8)


# the branch chief was testing you! If you made it this far, she has decided
# not to let you go. Congrats!  




